import { refreshList } from './mvc/view';

import './utils/libraries';

refreshList();
